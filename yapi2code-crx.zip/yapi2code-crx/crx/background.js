/*chrome.runtime.onInstalled.addListener(() => {
  if (window.location.hostname.includes('yapi')) {
    chrome.browserAction.setBadgeText({ text: 'on' })
    chrome.browserAction.setBadgeBackgroundColor({ color: '#3de1ad' })
  } else {
    chrome.browserAction.setBadgeText({ text: 'off' })
    chrome.browserAction.setBadgeBackgroundColor({ color: 'lightgrey' })
  }
})*/
